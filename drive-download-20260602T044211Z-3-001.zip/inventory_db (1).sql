-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2026 at 11:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `pddescription` varchar(100) NOT NULL,
  `date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `category`, `quantity`, `price`, `pddescription`, `date`) VALUES
(12, 'Mouse', 'Accessories', 3, 500, 'Wireless Mouse', '2026-05-03 06:49:40'),
(13, 'Keyboard', 'Electronics', 0, 1200, 'Mechanical Keyboard', '2026-05-04 06:49:35'),
(14, 'Iphone 17', 'Electronics', 10, 20000, 'promax', '2026-05-12 06:49:22'),
(19, '', 'Select Here', 0, 0, '', '2026-05-21 05:48:47'),
(20, 'Ballpoint Pen', 'Office Supplies', 10, 300, 'One bundle, Medium', '2026-05-21 17:48:21'),
(22, 'Windows 11', 'Electronics', 3, 20000, '800RAM', '2026-05-21 18:13:58');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `profile_id` int(50) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `civil_status` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `phonenum` varchar(50) NOT NULL,
  `Age` int(11) NOT NULL,
  `role_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile_users`
--

CREATE TABLE `profile_users` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(20) DEFAULT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `proflie_users`
--

CREATE TABLE `proflie_users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `civil_status` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `proflie_users`
--

INSERT INTO `proflie_users` (`user_id`, `first_name`, `last_name`, `address`, `phone_number`, `age`, `civil_status`, `role`, `username`, `password`) VALUES
(1, 'lex', 'dorna', 'golden', '09535072708', 19, 'Single', 'Admin', 'lexi', 'dorns'),
(2, 'lex', 'dorna', 'golden', '09535072708', 19, '', 'Admin', 'alexia', 'dorna'),
(3, 'lex', 'dorna', 'golden', '09535072708', 18, 'Single', 'Admin', 'lexy', 'dorna'),
(4, 'lex', 'dorna', 'golden', '09535072708', 18, '', 'Cashier', 'lexxx', 'dorna'),
(5, 'lex', 'dorna', 'golden', '0956502807', 17, 'Single', 'Admin', 'lex2', 'dorns'),
(6, 'lexia', 'dorna', 'golden', '0978236287', 17, '', 'Admin', 'lexia', 'dorna'),
(7, 'john', 'genite', 'aleal', '09278028316', 20, 'Single', 'Admin', 'JM123', 'Password'),
(8, 'Jesryl', 'Comeling', 'Maragusan', '09093934371', 67, 'Married', 'Cashier', 'jesryl', 'gwapoko'),
(9, 'Jesryl ', 'Comeling', 'Maragusan', '09676767676', 19, 'Taken', 'Admin', 'gwapo', 'nigga'),
(10, 'Alexia Jae', 'Dorna', 'Panabo City', '09535072708', 22, '', 'Admin', 'alexia', 'dorna');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`) VALUES
(3, 'lexi', '0', 'Admin'),
(4, 'alexia', '0', 'Admin'),
(5, 'lexy', '0', 'Admin'),
(6, 'lexxx', '0', 'Cashier'),
(7, 'lex2', '0', 'Admin'),
(10, 'lexi', 'dorns', 'Admin'),
(11, 'alexia', 'dorna', 'Admin'),
(12, 'lexy', 'dorna', 'Admin'),
(13, 'lexxx', 'dorna', 'Cashier'),
(14, 'lex2', 'dorns', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`profile_id`);

--
-- Indexes for table `profile_users`
--
ALTER TABLE `profile_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `proflie_users`
--
ALTER TABLE `proflie_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `profile_id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile_users`
--
ALTER TABLE `profile_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `proflie_users`
--
ALTER TABLE `proflie_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `profile_users`
--
ALTER TABLE `profile_users`
  ADD CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
